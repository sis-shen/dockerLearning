#include "test/jemalloc_test.h"

void *
btalloc(size_t size, unsigned bits) {
	return btalloc_0(size, bits);
}
